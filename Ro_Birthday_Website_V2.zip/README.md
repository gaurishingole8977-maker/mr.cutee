# Ro Birthday Website — Version 2 💗

A dramatic/cute birthday microsite for Ro from Gauri.

Features:
- Secret entry screen (password: `MAKDA` or `BABY`)
- Birthday countdown to 15 October 2026
- Interactive birthday quiz
- Photo gallery using the supplied photos
- Memory timeline
- Funny roast
- Romantic birthday letter
- Final surprise + heart animation
- Mobile-friendly

## GitHub Pages
Upload `index.html` and the `images` folder to a GitHub repository. Then enable GitHub Pages from Settings → Pages, using the main branch and root folder.
